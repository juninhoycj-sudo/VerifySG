import Anthropic from "@anthropic-ai/sdk";
import { NextRequest, NextResponse } from "next/server";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const { content } = await req.json();
    if (!content?.trim()) {
      return NextResponse.json({ error: "No content provided" }, { status: 400 });
    }

    const message = await client.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1024,
      system: `You are SafeSG, an AI scam detection assistant for Singapore. Analyze the provided text/URL/message for scam indicators.
Respond ONLY with a JSON object (no markdown, no backticks) in this exact format:
{
  "riskLevel": "HIGH" | "MEDIUM" | "LOW",
  "riskScore": <0-100 integer>,
  "verdict": "<one short sentence verdict>",
  "scamType": "<type of scam or 'Likely Legitimate'>",
  "redFlags": ["<flag 1>", "<flag 2>"],
  "whatToDo": ["<action 1>", "<action 2>"],
  "explanation": "<2-3 sentence explanation>"
}`,
      messages: [{ role: "user", content: `Analyze this for scams: ${content}` }],
    });

    const text = message.content.map((b) => (b.type === "text" ? b.text : "")).join("");
    const clean = text.replace(/```json|```/g, "").trim();
    const result = JSON.parse(clean);
    return NextResponse.json(result);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Analysis failed" }, { status: 500 });
  }
}
