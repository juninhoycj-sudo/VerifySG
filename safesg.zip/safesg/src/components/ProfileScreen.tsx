"use client";

const STATS = [
  { label: "Scans Run",     value: 24, icon: "🔍" },
  { label: "Scams Caught",  value: 7,  icon: "🛡️" },
  { label: "Reports Filed", value: 3,  icon: "📋" },
  { label: "Circles",       value: 3,  icon: "👥" },
];

const BADGES = [
  { icon: "🛡️", name: "First Scan",      earned: true  },
  { icon: "🔍", name: "Scam Buster",     earned: true  },
  { icon: "📢", name: "Community Hero",  earned: true  },
  { icon: "🌟", name: "Shield Master",   earned: false },
  { icon: "🔒", name: "Fort Knox",       earned: false },
  { icon: "🏆", name: "Top Defender",    earned: false },
];

export default function ProfileScreen() {
  return (
    <div style={{ padding: "24px 20px" }}>
      {/* Avatar */}
      <div style={{ textAlign: "center", marginBottom: 32 }}>
        <div style={{
          width: 76, height: 76, borderRadius: "50%",
          background: "rgba(0,212,255,0.1)", border: "2px solid var(--accent)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 34, margin: "0 auto 12px",
        }}>
          🧑
        </div>
        <h2 style={{ fontSize: 20, fontWeight: 700, color: "var(--text-primary)" }}>Juninho</h2>
        <p style={{ color: "var(--text-muted)", fontSize: 13, marginTop: 4 }}>SafeSG Member · Singapore 🇸🇬</p>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 28 }}>
        {STATS.map((s) => (
          <div key={s.label} className="card" style={{ textAlign: "center", padding: "14px 12px" }}>
            <div style={{ fontSize: 24, marginBottom: 6 }}>{s.icon}</div>
            <div style={{ color: "var(--accent)", fontSize: 24, fontWeight: 800 }}>{s.value}</div>
            <div style={{ color: "var(--text-muted)", fontSize: 12, marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Badges */}
      <h3 style={{ fontSize: 16, fontWeight: 600, color: "var(--text-primary)", marginBottom: 14 }}>Badges</h3>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
        {BADGES.map((b) => (
          <div key={b.name} className="card" style={{ textAlign: "center", padding: "14px 8px", opacity: b.earned ? 1 : 0.35 }}>
            <div style={{ fontSize: 30, marginBottom: 8 }}>{b.icon}</div>
            <div style={{ color: b.earned ? "var(--text-primary)" : "var(--text-muted)", fontSize: 11, fontWeight: b.earned ? 600 : 400 }}>{b.name}</div>
            {b.earned && <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#2ed573", margin: "8px auto 0" }} />}
          </div>
        ))}
      </div>
    </div>
  );
}
