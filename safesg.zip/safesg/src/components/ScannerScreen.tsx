"use client";
import { useState, useEffect } from "react";
import { ScanResult } from "@/lib/types";
import { ShieldIcon, RiskBadge, getRiskColors } from "@/components/ui";

export default function ScannerScreen() {
  const [input, setInput]       = useState("");
  const [mode, setMode]         = useState<"text" | "url">("text");
  const [scanning, setScanning] = useState(false);
  const [result, setResult]     = useState<ScanResult | null>(null);
  const [dots, setDots]         = useState(0);
  const [reported, setReported] = useState(false);

  useEffect(() => {
    if (!scanning) return;
    const t = setInterval(() => setDots((d) => (d + 1) % 4), 400);
    return () => clearInterval(t);
  }, [scanning]);

  const scan = async () => {
    if (!input.trim()) return;
    setScanning(true);
    setResult(null);
    setReported(false);
    try {
      const res = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: input }),
      });
      const data: ScanResult = await res.json();
      setResult(data);
    } catch {
      setResult({
        riskLevel: "MEDIUM", riskScore: 50,
        verdict: "Could not analyse — treat with caution.",
        scamType: "Unknown",
        redFlags: ["Analysis failed — err on the side of caution"],
        whatToDo: ["Do not click any links", "Verify through official channels"],
        explanation: "The analysis service encountered an error. When in doubt, do not engage.",
      });
    }
    setScanning(false);
  };

  const { color: riskColor, glow: riskGlow } = result ? getRiskColors(result.riskLevel) : { color: "var(--accent)", glow: "rgba(0,212,255,0.1)" };

  return (
    <div style={{ padding: "24px 20px" }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: "var(--text-primary)" }}>Scam Scanner</h1>
        <p style={{ color: "var(--text-secondary)", fontSize: 14, marginTop: 4 }}>Paste a message, URL, or describe what you received</p>
      </div>

      {/* Mode tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        {(["text", "url"] as const).map((m) => (
          <button key={m} onClick={() => setMode(m)} style={{
            background: mode === m ? "rgba(0,212,255,0.1)" : "transparent",
            border: `1px solid ${mode === m ? "var(--accent)" : "var(--border)"}`,
            borderRadius: 8, padding: "6px 16px",
            color: mode === m ? "var(--accent)" : "var(--text-muted)",
            cursor: "pointer", fontSize: 13, fontWeight: mode === m ? 600 : 400,
          }}>
            {m === "text" ? "📝 Text / Message" : "🔗 URL / Link"}
          </button>
        ))}
      </div>

      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        rows={5}
        placeholder={mode === "url" ? "Paste a suspicious URL here..." : "Paste the suspicious message, SMS, or email..."}
        style={{ resize: "none", lineHeight: 1.6 }}
      />

      <button
        onClick={scan}
        disabled={scanning || !input.trim()}
        style={{
          width: "100%", marginTop: 12,
          background: scanning ? "rgba(0,212,255,0.1)" : "var(--accent)",
          border: scanning ? "1px solid var(--accent)" : "none",
          borderRadius: 10, padding: "14px",
          color: scanning ? "var(--accent)" : "#0a0e1a",
          fontWeight: 700, fontSize: 15, cursor: scanning ? "default" : "pointer",
          display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
          opacity: !scanning && !input.trim() ? 0.5 : 1,
          transition: "all 0.2s",
        }}
      >
        {scanning ? (
          <><span className="spinner" />{`Analysing${".".repeat(dots)}`}</>
        ) : (
          <><ShieldIcon size={18} color="#0a0e1a" /> Scan Now</>
        )}
      </button>

      {result && (
        <div className="fade-in" style={{ marginTop: 28 }}>
          {/* Risk card */}
          <div className="card" style={{ marginBottom: 14, border: `1px solid ${riskColor}44`, background: riskGlow }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
              <div>
                <p style={{ color: "var(--text-muted)", fontSize: 11, letterSpacing: 1, marginBottom: 4 }}>RISK LEVEL</p>
                <p style={{ color: riskColor, fontSize: 30, fontWeight: 800, lineHeight: 1 }}>{result.riskLevel}</p>
                <p style={{ color: "var(--text-secondary)", fontSize: 13, marginTop: 4 }}>{result.scamType}</p>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 44, fontWeight: 800, color: riskColor, lineHeight: 1 }}>{result.riskScore}</div>
                <div style={{ color: "var(--text-muted)", fontSize: 12 }}>/ 100</div>
              </div>
            </div>
            <div style={{ background: "var(--bg)", borderRadius: 6, height: 8, overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${result.riskScore}%`, background: riskColor, borderRadius: 6, transition: "width 1.2s ease" }} />
            </div>
            <p style={{ color: "var(--text-secondary)", fontSize: 13, marginTop: 12, fontStyle: "italic" }}>"{result.verdict}"</p>
          </div>

          {/* Red flags */}
          {result.redFlags?.length > 0 && (
            <div className="card" style={{ marginBottom: 12 }}>
              <p style={{ color: "#ff4757", fontWeight: 600, fontSize: 14, marginBottom: 10 }}>🚩 Red Flags</p>
              {result.redFlags.map((f, i) => (
                <div key={i} style={{ display: "flex", gap: 8, marginBottom: 6 }}>
                  <span style={{ color: "#ff4757" }}>•</span>
                  <span style={{ color: "var(--text-secondary)", fontSize: 13 }}>{f}</span>
                </div>
              ))}
            </div>
          )}

          {/* What to do */}
          <div className="card" style={{ marginBottom: 12 }}>
            <p style={{ color: "#2ed573", fontWeight: 600, fontSize: 14, marginBottom: 10 }}>✅ What To Do</p>
            {result.whatToDo?.map((a, i) => (
              <div key={i} style={{ display: "flex", gap: 8, marginBottom: 6 }}>
                <span style={{ color: "#2ed573" }}>{i + 1}.</span>
                <span style={{ color: "var(--text-secondary)", fontSize: 13 }}>{a}</span>
              </div>
            ))}
          </div>

          {/* Explanation */}
          <div className="card" style={{ marginBottom: 16 }}>
            <p style={{ color: "var(--text-muted)", fontSize: 11, letterSpacing: 1, marginBottom: 6 }}>ANALYSIS</p>
            <p style={{ color: "var(--text-secondary)", fontSize: 13, lineHeight: 1.7 }}>{result.explanation}</p>
          </div>

          {result.riskLevel !== "LOW" && !reported && (
            <button
              onClick={() => setReported(true)}
              style={{
                width: "100%", background: "rgba(255,71,87,0.1)", border: "1px solid rgba(255,71,87,0.27)",
                borderRadius: 10, padding: 14, color: "#ff4757", fontWeight: 600, fontSize: 14, cursor: "pointer",
              }}
            >
              ⚠️ Report to Community
            </button>
          )}
          {reported && (
            <div className="card" style={{ background: "rgba(46,213,115,0.1)", border: "1px solid rgba(46,213,115,0.27)", textAlign: "center" }}>
              <p style={{ color: "#2ed573", fontWeight: 600, fontSize: 15 }}>✅ Report submitted</p>
              <p style={{ color: "var(--text-muted)", fontSize: 13, marginTop: 4 }}>Thank you for keeping Singapore safe</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
