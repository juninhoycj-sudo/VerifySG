import { CommunityAlert, Circle } from "./types";

export const COMMUNITY_ALERTS: CommunityAlert[] = [
  { id: 1, type: "Phishing", title: "OCBC Bank SMS Scam", summary: "Fake OCBC alerts asking victims to verify accounts via suspicious link", risk: "HIGH", reports: 847, time: "2h ago", tags: ["SMS", "Banking"] },
  { id: 2, type: "Job Scam", title: "Fake Part-Time Job Offer", summary: "WhatsApp messages offering $3000/day for simple online tasks — requires upfront payment", risk: "HIGH", reports: 1203, time: "4h ago", tags: ["WhatsApp", "Employment"] },
  { id: 3, type: "E-commerce", title: "Carousell Payment Scam", summary: "Sellers requesting PayNow before shipping, then disappearing after payment", risk: "MEDIUM", reports: 392, time: "6h ago", tags: ["Carousell", "PayNow"] },
  { id: 4, type: "Romance Scam", title: "Dating App Investment Scam", summary: "Individuals building fake romantic relationships before introducing crypto investment platforms", risk: "HIGH", reports: 218, time: "1d ago", tags: ["Dating", "Crypto"] },
  { id: 5, type: "Impersonation", title: "SPF Officer Scam", summary: "Callers impersonating Singapore Police Force demanding immediate bank transfers", risk: "HIGH", reports: 561, time: "1d ago", tags: ["Phone", "Gov't"] },
];

export const INITIAL_CIRCLES: Circle[] = [
  { id: 1, name: "Family", members: 5, avatar: "👨‍👩‍👧‍👦", alerts: 2 },
  { id: 2, name: "NS Mates", members: 12, avatar: "🪖", alerts: 0 },
  { id: 3, name: "NUS CS Classmates", members: 28, avatar: "🎓", alerts: 1 },
];
